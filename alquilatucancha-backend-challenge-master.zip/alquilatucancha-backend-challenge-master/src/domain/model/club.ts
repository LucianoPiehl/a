export interface Club {
  id: number;
  // TODO: fill
}
