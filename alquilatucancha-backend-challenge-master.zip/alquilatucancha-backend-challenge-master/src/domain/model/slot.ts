export interface Slot {
  price: number;
  duration: number;
  datetime: string;
  start: string;
  end: string;
  _priority: number;
}
