export interface Court {
  id: number;
  // TODO: fill
}
